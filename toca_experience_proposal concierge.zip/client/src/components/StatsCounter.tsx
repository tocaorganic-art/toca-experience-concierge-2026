import { useEffect, useRef, useState } from "react";
import { Users, CheckCircle, Heart } from "lucide-react";

interface StatItem {
  icon: React.ReactNode;
  label: string;
  value: number;
  suffix?: string;
}

export function StatsCounter() {
  const [isVisible, setIsVisible] = useState(false);
  const [counts, setCounts] = useState({ clients: 0, reservations: 0, satisfaction: 0 });
  const ref = useRef<HTMLDivElement>(null);

  const stats: StatItem[] = [
    {
      icon: <Users size={28} />,
      label: "Clientes Satisfeitos",
      value: 500,
      suffix: "+",
    },
    {
      icon: <CheckCircle size={28} />,
      label: "Reservas Realizadas",
      value: 150,
      suffix: "+",
    },
    {
      icon: <Heart size={28} />,
      label: "Taxa de Satisfação",
      value: 98,
      suffix: "%",
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true);
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, [isVisible]);

  // Animate counters when visible
  useEffect(() => {
    if (!isVisible) return;

    const duration = 2000; // 2 seconds
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);

      setCounts({
        clients: Math.floor(500 * progress),
        reservations: Math.floor(150 * progress),
        satisfaction: Math.floor(98 * progress),
      });

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [isVisible]);

  return (
    <div
      ref={ref}
      className="py-12 px-4 bg-gradient-to-r from-[rgb(201_168_76)]/5 to-[rgb(154_122_46)]/5 border-y border-[rgb(201_168_76)]/20"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`flex flex-col items-center text-center transition-all duration-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
              style={{
                transitionDelay: isVisible ? `${index * 150}ms` : "0ms",
              }}
            >
              {/* Icon */}
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[rgb(201_168_76)]/20 to-[rgb(154_122_46)]/20 border border-[rgb(201_168_76)]/30 flex items-center justify-center mb-4">
                <div className="text-[rgb(201_168_76)]">{stat.icon}</div>
              </div>

              {/* Counter */}
              <div className="mb-2">
                <span className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-[rgb(201_168_76)] to-[rgb(232_208_138)] bg-clip-text text-transparent">
                  {index === 0
                    ? counts.clients
                    : index === 1
                      ? counts.reservations
                      : counts.satisfaction}
                  {stat.suffix}
                </span>
              </div>

              {/* Label */}
              <p className="text-sm md:text-base text-gray-400 font-medium">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
